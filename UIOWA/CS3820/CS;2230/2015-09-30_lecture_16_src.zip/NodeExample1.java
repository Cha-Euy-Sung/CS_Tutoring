/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication13;

/**
 *
 * @author mmonsalv
 */
public class NodeExample1 {

    static class Node {

        public Node next;
        public char daChar;

        public Node(char arg) {
            next = null;
            daChar = arg;
        }

        public void append(char arg) {
            if (next==null)
                next = new Node(arg);
            else
                next.append(arg);
        }
    }

    public static void main(String[] xxxxx) {
        Node a = new Node('h');
        a.append('e');
        a.append('l');
        a.append('l');
        a.append('o');
        for (Node j = a; j != null; j = j.next) {
            System.out.print(j.daChar + " ");
        }
    }

}
