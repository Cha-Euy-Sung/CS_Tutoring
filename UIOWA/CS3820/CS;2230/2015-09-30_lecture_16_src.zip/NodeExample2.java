/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication13;

/**
 *
 * @author mmonsalv
 */
public class NodeExample2 {

    static class Node {

        public Node next;
        public char daChar;

        public Node(char arg) {
            next = null;
            daChar = arg;
        }

        public void append(char arg) {
            if (next==null)
                next = new Node(arg);
            else
                next.append(arg);
        }
    }
    
    static class CharLL {
        Node head;
        public CharLL() {
            head = null;
        }
        public CharLL(char arg) {
            head = new Node(arg);
        }
        public CharLL(String txt) {
            head = new Node(txt.charAt(0));
            for(int i=1;i<txt.length();i++)
                head.append(txt.charAt(i));
        }
        public void append(String txt) {
            for(int i=0;i<txt.length();i++)
                head.append(txt.charAt(i));
        }
    }

    public static void main(String[] xxxxx) {
        CharLL ll = new CharLL("Whatever");
        for (Node j = ll.head; j != null; j = j.next) {
            System.out.print(j.daChar + " ");
        }
    }

}
