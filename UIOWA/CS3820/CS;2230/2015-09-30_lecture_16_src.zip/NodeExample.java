/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication13;

/**
 *
 * @author mmonsalv
 */
public class NodeExample {

    static class Node {

        public Node next;
        public int size;

        public Node() {
            next = null;
            size = 1;
        }

        public Node(Node nxt) {
            next = nxt;
            size = nxt.size + 1;
        }
    }

    public static void main(String[] xxxxx) {
        Node a = new Node();
        Node b = new Node(a);
        Node c = new Node(b);
        Node d = new Node(c);
        for (Node j = d; j != null; j = j.next) {
            System.out.println(j.size);
        }
    }

}
