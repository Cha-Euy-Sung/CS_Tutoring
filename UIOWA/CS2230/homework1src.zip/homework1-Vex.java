class Vex {

  int x, y, z;

  public Vex( int x, int y, int z ) {
    this.x = x;
    this.y = y;
    this.z = z;
  }

  public String toString() {
    return "Vex( " + x + ", " + y + ", " + z + " )";
  }

  public Vex add( Vex other ) {
    int new_x = this.x + other.x,
        new_y = this.y + other.y,
        new_z = this.z + other.z;
    return new Vex( new_x , new_y, new_z );
  }

  // the methods below must be implemented by you
  public Vex subtract( Vex other )
  public Vex scalarMult( int scale )
  public int innerMult( Vex other )
  public int norm1()
  public double norm2()
  public boolean equals( Vex other )
  public Vex clone()

}