class charMaster {

  public static String char2str(char[] x) {
    // creates a new string out of the char array, for
    // example: {'h','e','l','l','o'} --> "hello"
  }

  public static char[] str2char(String x) {
    // creates a new char array out of the String, for
    // example: "hello" --> {'h','e','l','l','o'}
  }

  public static char[] reverse(char[] x) {
    // creates a new char array that contains the elements
    // of c in reverse order, for example:
    // {'h','e','l','l','o'} --> {'o','l','l','e','h'}
  }

  public static int count(char c, char[] x) {
    // returns the number of times character c appears in
    // the array of characters x
  }

  public static char[] clone(char[] x) {
    // returns a new char array with the same elements as c
  }

  public static boolean equals(char[] x, char[] y) {
    // true if and only if x and y have the same contents
  }

}
